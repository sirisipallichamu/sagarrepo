
var products = [
    {
        name:"Shoe",
        image:'images/1.jpg',
        price:1000
    },{},{}

];

