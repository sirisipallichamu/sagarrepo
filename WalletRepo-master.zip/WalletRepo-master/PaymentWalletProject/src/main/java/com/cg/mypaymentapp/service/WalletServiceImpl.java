
package com.cg.mypaymentapp.service;
import java.math.BigDecimal;

import com.cg.mypaymentapp.beans.Customer;


public class WalletServiceImpl implements WalletService{

	public Customer createAccount(String name, String mobileno,
			BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}


	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

}
