Restore the sakila.sql dump into your database.
All examples are based on the "sakila" database.# MySQL 
