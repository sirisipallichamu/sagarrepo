/**
 * Created by sagar on 5/4/14.
 */

define(['dojo/ready','dojox/validate/web'], function(ready){
    ready(function(){
        console.log('ready !!');
    });
});