/**
 * Created by sagar on 5/4/14.
 */

define(['dojo/ready','./validate'],function(ready){
    ready(function(){
        console.log('ready');
    });
});