/**
 * Created by sagakulk on 6/17/2015.
 */
$(function(){
    $address = $('address').text();
    console.log($address);
    $('address').text('D-10 Chintamani Nagar, Pune');

   // $('p').text('item');
});