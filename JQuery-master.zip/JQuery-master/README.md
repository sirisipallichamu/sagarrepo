JQuery Examples 
