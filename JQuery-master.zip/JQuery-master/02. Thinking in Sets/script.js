/**
 * Created by sagakulk on 6/17/2015.
 */
$(function(){
    var $div = $('div');
    console.log($div.length);
});