/**
 * Created by sagakulk on 6/17/2015.
 */
$(function(){
   var $buttons = $('.addtocartbutton');
    console.log($buttons.length);

   var $headername = $('#headername');
    console.log($headername[0]);
});